# Личный проект «Таинственный отпуск» [![Build status][travis-image]][travis-url] [![Dependency status][dependency-image]][dependency-url]

* Студент: [Татьяна Венидиктова](https://up.htmlacademy.ru/animation/1/user/1851311).

---

**Обратите внимание, что папка с вашими исходными файлами — `source/`.**

Полезный файл:

- [Contributing.md](Contributing.md) — руководство по внесению изменений.

_Не удаляйте и не обращайте внимание на файлы:_<br>
_`.editorconfig`, `.gitattributes`, `.gitignore`, `.stylelintrc`, `.travis.yml`, `package-lock.json`, `package.json`._

---

### Памятка

#### 1. Зарегистрируйтесь на Гитхабе

Если у вас ещё нет аккаунта на [github.com](https://github.com/join), скорее зарегистрируйтесь.

#### 2. Создайте форк

[Откройте мастер-репозиторий](https://github.com/htmlacademy-animation/1851311-magic-vacation-1) и нажмите кнопку «Fork» в правом верхнем углу. Репозиторий из Академии будет скопирован в ваш аккаунт.

<img width="800" alt="" src="https://user-images.githubusercontent.com/8537950/80361146-1efcc300-8889-11ea-8aec-b03aa0dc5958.png">

Получится вот так:

<img width="800" alt="" src="https://user-images.githubusercontent.com/8537950/80361174-2de37580-8889-11ea-9908-ae62e62a21f2.png">

#### 3. Клонируйте репозиторий на свой компьютер

Будьте внимательны: нужно клонировать свой репозиторий (форк), а не репозиторий Академии. Также обратите внимание, что клонировать репозиторий нужно через SSH, а не через HTTPS. Нажмите зелёную кнопку в правой части экрана, чтобы скопировать SSH-адрес вашего репозитория:

<img width="800" alt="" src="https://user-images.githubusercontent.com/8537950/80361179-30de6600-8889-11ea-854d-d803465e4f59.png">

Клонировать репозиторий можно так:

```
git clone SSH-адрес_вашего_форка
```

Команда клонирует репозиторий на ваш компьютер и подготовит всё необходимое для старта работы.

#### 4. Начинайте обучение!

---

<a href="https://htmlacademy.ru/intensive/animation"><img align="left" width="50" height="50" alt="HTML Academy" src="https://up.htmlacademy.ru/static/img/intensive/htmlcss/logo-for-github-2.png"></a>

Репозиторий создан для обучения на профессиональном онлайн‑курсе «[Анимация для фронтендеров](https://htmlacademy.ru/intensive/animation)» от [HTML Academy](https://htmlacademy.ru).

[travis-image]: https://travis-ci.com/htmlacademy-animation/1851311-magic-vacation-1.svg?branch=master
[travis-url]: https://travis-ci.com/htmlacademy-animation/1851311-magic-vacation-1
[dependency-image]: https://david-dm.org/htmlacademy-animation/1851311-magic-vacation-1/dev-status.svg?style=flat-square
[dependency-url]: https://david-dm.org/htmlacademy-animation/1851311-magic-vacation-1?type=dev
