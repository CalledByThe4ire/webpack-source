export const CatFeature = {
  NEW: 'new',
  SOFT: 'soft',
};
export const AppRoute = {
  MAIN: '/',
  BUY: '/buy',
};

