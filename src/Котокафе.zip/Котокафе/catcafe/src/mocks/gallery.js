const gallery = [
  {
    id: 0,
    src: 'https://i.ibb.co/3fCdY56/1.jpg',
    alt: 'фото кота',
  },
  {
    id: 1,
    src: 'https://i.ibb.co/1YCmrQk/2.jpg',
    alt: 'фото кота1',
  },
  {
    id: 2,
    src: 'https://i.ibb.co/n1wHdjn/3.jpg',
    alt: 'фото кота2',
  },
  {
    id: 3,
    src: 'https://i.ibb.co/JkmZmS5/4.jpg',
    alt: 'фото кота3',
  },
];

export default gallery;
