export const AppRoute = {
  MAIN: '/',
  ORDER: '/order',
};
