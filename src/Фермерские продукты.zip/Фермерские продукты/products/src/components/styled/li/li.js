import styled from 'styled-components';

const Li = styled.li`
  list-style: none;
  vertical-align: top;
`;

export default Li;
