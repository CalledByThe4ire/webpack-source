import styled from 'styled-components';

const Label = styled.label`
  display: block;
`;

export default Label;
