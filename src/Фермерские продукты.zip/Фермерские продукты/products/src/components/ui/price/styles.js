import styled from 'styled-components';

export const StyledPrice = styled.span`
  display: block;
  font-size: 24px;
  font-weight: bold;
`;
