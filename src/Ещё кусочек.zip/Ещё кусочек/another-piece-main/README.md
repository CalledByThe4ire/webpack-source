# Стартовый шаблон Олега Цыганова
Используется связка `Gulp` + `Pug` + `SCSS` + `BrowserSync` + `Linters`

## Установка
Склонировать репозиторий и выполнить npm install

## Каналы связи
- [Telegram](https://tlgg.ru/redsmoke_smr)
