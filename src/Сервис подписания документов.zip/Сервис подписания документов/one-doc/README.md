# levelup-ds-module-3
 
для начала работы `npm i && npm start`  

`./css/components` — компоненты дизайн системы  
`./css/helpers`, `./js/helpers` — файлы витрины  

parcel подключен для HMR