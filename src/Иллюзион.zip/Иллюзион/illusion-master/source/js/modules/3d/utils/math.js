export const degToRadians = (deg) => (deg * Math.PI) / 180;
