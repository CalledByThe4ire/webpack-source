const ObjectMaterialType = {
  DEFAULT: 'Dark',
  VERSICOLOR: 'Versicolor',
  PARSE: 'ParseObjectPartsMaterialNames'
};

export default ObjectMaterialType;
