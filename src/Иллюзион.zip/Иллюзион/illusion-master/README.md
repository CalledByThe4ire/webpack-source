# illusion

- Resolve deps -
```
npm i
```

- Run server -
```
npm start
```

- Build -
```
npm run build
```

