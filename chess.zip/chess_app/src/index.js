import './main.css';
console.log('Hello world on main page!');
