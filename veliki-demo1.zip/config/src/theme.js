const Theme = {
  ADULT: 'adult',
  CHILD: 'child'
};

export { Theme };
