import { useMemo } from "react";
import { Theme } from "../theme";

import news1Adult from "../images/news/news-1-adult.jpg";
import news1Child from "../images/news/news-1-child.jpg";

import news2Adult from "../images/news/news-2-adult.jpg";
import news2Child from "../images/news/news-2-child.jpg";

import news3Adult from "../images/news/news-3-adult.jpg";
import news3Child from "../images/news/news-3-child.jpg";

const useMockNews = (theme = Theme.ADULT) => {
  return useMemo(() => [
    {
      id: 1,
      title: theme === Theme.ADULT ? "Велопробег в Москве" : "Гонки на великах",
      date: theme === Theme.ADULT ? "02.04.2022" : "12.04.2022",
      image: theme === Theme.ADULT ? news1Adult : news1Child,
      imageAlt: theme === Theme.ADULT ? "Велосипедисты едут по дороге в пасмурный день" : "Мальчики едут по гоночной трассе"
    },
    {
      id: 2,
      title: theme === Theme.ADULT ? "Велик зимой" : "Прогулки с детьми",
      date: theme === Theme.ADULT ? "21.01.2022" : "30.02.2022",
      image: theme === Theme.ADULT ? news2Adult : news2Child,
      imageAlt: theme === Theme.ADULT ? "Велик в сугробе на фоне гор" : "Малыш с беговелом"
    },
    {
      id: 3,
      title: theme === Theme.ADULT ? "В длинную дорогу" : "Безопасная езда",
      date: theme === Theme.ADULT ? "17.10.2021" : "27.11.2021",
      image: theme === Theme.ADULT ? news3Adult : news3Child,
      imageAlt: theme === Theme.ADULT ? "Велик в поле на закате" : "Мальчик в шлеме едет очень быстро"
    }
  ], [theme]);
};

export { useMockNews };
