import { useMemo } from "react";
import { Theme } from "../theme";
import { BannerSize } from "../components/banner";
import banner1Adult from "../images/banners/banner-1-adult.jpg";
import banner1Child from "../images/banners/banner-1-child.jpg";

import banner2Adult from "../images/banners/banner-2-adult.jpg";
import banner2Child from "../images/banners/banner-2-child.jpg";

import banner3Adult from "../images/banners/banner-3-adult.jpg";
import banner3Child from "../images/banners/banner-3-child.jpg";


const useMockBanners = (theme = Theme.ADULT) => {
  return useMemo(() => [
    {
      id: 1,
      size: BannerSize.LARGE,
      title: theme === Theme.ADULT ? "Трековые велики" : "Беговелы",
      discount: theme === Theme.ADULT ? 50 : 30,
      image: theme === Theme.ADULT ? banner1Adult : banner1Child,
      imageAlt: theme === Theme.ADULT ? "Чёрный трековый велик" : "Мальчик едет на деревянном беговеле"
    },
    {
      id: 2,
      size: BannerSize.MEDIUM,
      title: theme === Theme.ADULT ? "Цветные покрышки" : "Крутые велики",
      image: theme === Theme.ADULT ? banner2Adult : banner2Child,
      imageAlt: theme === Theme.ADULT ? "Белый обод с красной покрышкой" : "Дети в шлемах и гоночные велики"
    },
    {
      id: 3,
      size: BannerSize.MEDIUM,
      title: theme === Theme.ADULT ? "Стильные велики" : "Велики для девчонок",
      image: theme === Theme.ADULT ? banner3Adult : banner3Child,
      imageAlt: theme === Theme.ADULT ? "Голубой прогулочный велик" : "Девочка в шлеме едет на голубом велике"
    }
  ], [theme]);
};

export { useMockBanners };
