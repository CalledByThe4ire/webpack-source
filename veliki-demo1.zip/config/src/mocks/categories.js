import { useMemo } from "react";
import { Theme } from "../theme";

import category1Adult from "../images/categories/category-1-adult.jpg";
import category1Child from "../images/categories/category-1-child.jpg";

import category2Adult from "../images/categories/category-2-adult.jpg";
import category2Child from "../images/categories/category-2-child.jpg";


import category3Adult from "../images/categories/category-3-adult.jpg";
import category3Child from "../images/categories/category-3-child.jpg";


const useMockCategories = (theme = Theme.ADULT) => {
  return useMemo(() => [
    {
      id: 1,
      name: theme === Theme.ADULT ? "Трековые" : "Беговелы",
      modelAmount: theme === Theme.ADULT ? 156 : 116,
      image: theme === Theme.ADULT ? category1Adult : category1Child,
      imageAlt: theme === Theme.ADULT ? "Белый трековый велик" : "Белый беговел"
    },
    {
      id: 2,
      name: theme === Theme.ADULT ? "Горные" : "Трехколесные",
      modelAmount: theme === Theme.ADULT ? 125 : 98,
      image: theme === Theme.ADULT ? category2Adult : category2Child,
      imageAlt: theme === Theme.ADULT ? "Серый горный велик" : "Красный трехколесный велик"
    },
    {
      id: 3,
      name: theme === Theme.ADULT ? "Повседневные" : "Подростковые",
      modelAmount: theme === Theme.ADULT ? 189 : 173,
      image: theme === Theme.ADULT ? category3Adult : category3Child,
      imageAlt: theme === Theme.ADULT ? "Красный повседневный велик" : "Голубой подростковый велик"
    }
  ], [theme]);
};

export { useMockCategories };
