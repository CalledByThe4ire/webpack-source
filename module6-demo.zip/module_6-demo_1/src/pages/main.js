import btnHandler from '../js/btnHandler';
import './main.scss';
btnHandler();
