module.exports = {
  plugins: [['autoprefixer']],
};
